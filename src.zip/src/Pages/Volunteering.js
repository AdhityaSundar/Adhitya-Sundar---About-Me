import React from "react";
import "../Styles/Volunteering.css";

function Volunteering() {

    return(<div className="volunteering">
        {/* <div className="grid">
                    
                    <div className="item">

                        <img className="robot_hand" id="Udavam_Karangal" src = {AIHand}/>

                    </div>
        </div>             */}

        <h1> Volunteering (FTC) </h1>      
              
        <p> I am volunteering with various charities such as Volunteer One (My charity 4 kids) and Udavum karangal. Volunteer One helps to feed the homeless and people in need. Udavum Karangal is an orphanage for all ages of people in need. </p>
        
        <p> To become a volunteer like me in My Charity for Kids, or to donate to support (Add Volunteer ph-1) and select the following link: <a href="https://google.com"> Charity Link </a> </p>
        
        <p> To become a volunteer like me or to donate to Udavum Karangal (Add Volunteer ph-2), select the following link: <a href="https://www.google.com/"> Click Here </a> </p>

        <p> Tutoring: I am currently tutoring Elementary and young middle schoolers to enhance their skills and interest in coding, cyber security and Math on a needed basis.</p>

    </div>);        

} 

export default Volunteering;