import React from "react";
import "../Styles/Achievements.css";

function Achievements() {

    return(<div className="achievements">

        <h1> Achievements and Awards </h1>      
        
    </div>);        

} 

export default Achievements;