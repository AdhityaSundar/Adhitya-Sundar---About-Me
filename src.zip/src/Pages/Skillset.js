import React from "react";
import "../Styles/Skillset.css";

    function Skillset() {

        return( <div className="skills">
        <div className="skills">
                <h1> SKILLSET </h1>
                <ul className="list">
                    <li className="item"> <h2>Programming</h2> <span>PROGRAMMING IN JAVA, HTML, CSS, JAVASCRIPT, SPRINGBOOT, AND SQL</span></li>
                    <li className="item"> <h2>Robotics</h2> <span>DESIGNING AND BUILDING INNOVATIVE ROBOTS</span></li>
                    <li className="item"> <h2>Youtube</h2> <span>CREATING YOUTUBE EDUCATIONAL VIDEOS</span></li>
                    <li className="item"> <h2>Tutoring</h2> <span>TUTORING AND MENTORING KIDS FOR SCHOOL AND STEM ACTIVITIES</span></li>
                    </ul>
                </div>

            </div>);
                    }


export default Skillset;